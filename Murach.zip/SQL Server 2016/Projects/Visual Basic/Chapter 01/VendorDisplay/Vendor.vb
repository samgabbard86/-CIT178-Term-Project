﻿Imports Microsoft.VisualBasic

Public Class Vendor

    Public Sub New()

    End Sub

    Public Property VendorID As Integer

    Public Property VendorName As String

    Public Property VendorAddress1 As String

    Public Property VendorAddress2 As String

    Public Property VendorCity As String

    Public Property VendorState As String

    Public Property VendorZipCode As String

End Class
