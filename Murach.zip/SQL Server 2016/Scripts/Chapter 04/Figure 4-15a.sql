USE Examples;

SELECT FirstName, LastName
FROM Employees;