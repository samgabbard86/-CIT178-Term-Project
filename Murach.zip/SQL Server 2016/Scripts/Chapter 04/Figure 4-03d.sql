-- If necessary, you can use this stored procedure to drop
-- the linked server created by Figure 4-03c.sql

sp_dropserver 'DBServer', 'droplogins';
