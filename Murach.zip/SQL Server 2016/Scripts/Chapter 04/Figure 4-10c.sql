USE Examples;

SELECT * 
FROM Projects;