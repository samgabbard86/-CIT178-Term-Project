/*
   Before running this script, change the Windows
   domain name (Accounting) in the CREATE LOGIN
   statement to the name of your computer, and
   change the user name (SusanRoberts)to your
   Windows login ID.
*/
CREATE LOGIN [Accounting\SusanRoberts] FROM WINDOWS;