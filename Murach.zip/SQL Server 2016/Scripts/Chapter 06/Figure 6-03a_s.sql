USE AP;

-- The subquery
SELECT DISTINCT VendorID
FROM Invoices;
