USE AP;

-- The subquery
SELECT InvoiceTotal
FROM Invoices
WHERE VendorID = 34;
