USE AP;

INSERT Vendors
VALUES ('Peerless Uniforms, Inc.', '785 S Pixley Rd', NULL,
        'Piqua', 'Oh', '45356', '(937) 555-8845', NULL, NULL, 4,550);
