USE AP;

CREATE TABLE VendorsTest (VendorID int, VendorName varchar(50));

SELECT * FROM AuditDDL;

DROP TABLE VendorsTest;

SELECT * FROM AuditDDL;
