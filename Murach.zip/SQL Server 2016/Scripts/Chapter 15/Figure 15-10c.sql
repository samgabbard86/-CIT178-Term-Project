USE AP;

DROP PROC spVendorState;