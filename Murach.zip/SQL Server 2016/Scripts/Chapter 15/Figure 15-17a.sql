USE AP;

IF OBJECT_ID('Vendors_INSERT_UPDATE') IS NOT NULL
    DROP TRIGGER Vendors_INSERT_UPDATE;
GO

CREATE TRIGGER Vendors_INSERT_UPDATE
    ON Vendors
    AFTER INSERT,UPDATE
AS
    UPDATE Vendors
    SET VendorState = UPPER(VendorState)
    WHERE VendorID IN (SELECT VendorID FROM Inserted);
