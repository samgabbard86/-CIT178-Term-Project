USE AP;

UPDATE Invoices
SET PaymentTotal = 662, PaymentDate = '2016-05-09'
WHERE InvoiceID = 98;
