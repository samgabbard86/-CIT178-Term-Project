USE AP;

DROP VIEW Vendors_SW;