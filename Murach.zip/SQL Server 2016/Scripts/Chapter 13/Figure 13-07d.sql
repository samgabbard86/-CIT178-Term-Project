USE AP;

SELECT *
FROM Invoices;