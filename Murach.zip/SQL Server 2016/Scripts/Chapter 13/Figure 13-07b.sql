USE AP;

SELECT *
FROM VendorPayment;