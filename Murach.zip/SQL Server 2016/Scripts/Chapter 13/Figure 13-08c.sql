USE AP;

INSERT INTO IBM_Invoices
    (InvoiceNumber, InvoiceDate, InvoiceTotal)
VALUES ('RA23988', '2016-05-04', 417.34);
