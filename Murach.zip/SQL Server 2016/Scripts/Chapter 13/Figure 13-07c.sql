USE AP;

UPDATE VendorPayment
SET PaymentTotal = 19351.18, PaymentDate = '2016-04-02'
WHERE VendorName = 'Malloy Lithographing Inc' AND InvoiceNumber = 'P-0608';
