USE AP;

DELETE InvoiceCopy
WHERE VendorID = 37;
