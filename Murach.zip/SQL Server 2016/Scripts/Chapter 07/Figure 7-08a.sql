USE AP;

-- This statement assumes that you used the 
-- script stored in "Figure 7-02a.sql" to insert row 115
DELETE InvoiceCopy
WHERE InvoiceID = 115;
