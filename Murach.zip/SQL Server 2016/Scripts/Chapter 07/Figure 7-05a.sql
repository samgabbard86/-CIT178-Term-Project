USE AP;

UPDATE InvoiceCopy
SET PaymentDate = '2016-05-21', 
    PaymentTotal = 19351.18
WHERE InvoiceNumber = '97/522';