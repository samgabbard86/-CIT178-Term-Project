USE AP;

UPDATE InvoiceCopy
SET TermsID = 1
WHERE VendorID = 95;
