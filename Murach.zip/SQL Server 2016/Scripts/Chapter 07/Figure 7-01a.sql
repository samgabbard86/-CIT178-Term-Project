USE AP;

SELECT *
INTO InvoiceCopy
FROM Invoices;
