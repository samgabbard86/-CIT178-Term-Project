USE AP;

INSERT INTO InvoiceCopy 
    (VendorID, InvoiceNumber, InvoiceTotal, PaymentTotal, CreditTotal,
    TermsID, InvoiceDate, InvoiceDueDate)
VALUES
    (97, '456789', 8344.50, 0, 0, 1, '2016-04-01', '2016-04-30'); 

