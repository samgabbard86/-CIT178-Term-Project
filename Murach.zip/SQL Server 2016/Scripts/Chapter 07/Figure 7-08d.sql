USE AP;

DELETE InvoiceCopy;