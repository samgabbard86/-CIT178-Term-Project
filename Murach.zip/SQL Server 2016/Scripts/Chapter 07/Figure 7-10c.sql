USE AP;

DELETE FROM InvoiceArchive;