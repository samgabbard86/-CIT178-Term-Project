USE AP;

SELECT * FROM ContactUpdates;
