USE Examples;

SELECT * FROM DateSample
WHERE StartDate = CAST('10:00:00' AS datetime);


