USE Examples;

SELECT * FROM DateSample
WHERE CONVERT(date, StartDate) = '2011-10-28';

