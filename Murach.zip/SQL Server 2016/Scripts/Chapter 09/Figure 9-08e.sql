Use Examples;

SELECT * FROM DateSample
WHERE MONTH(StartDate) = 10 AND 
      DAY(StartDate) = 28 AND 
      YEAR(StartDate) = 2011;

