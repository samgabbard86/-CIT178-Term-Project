USE Examples;

SELECT *
FROM DateSample;