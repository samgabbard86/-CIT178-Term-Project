USE Examples;

SELECT * FROM DateSample
WHERE StartDate = '2011-10-28';
