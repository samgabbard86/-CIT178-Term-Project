USE Examples;

SELECT *
FROM NullSample;
