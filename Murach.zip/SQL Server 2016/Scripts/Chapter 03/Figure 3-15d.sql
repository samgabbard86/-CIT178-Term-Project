USE Examples;

SELECT *
FROM NullSample
WHERE InvoiceTotal IS NULL;

