USE Examples;

SELECT *
FROM NullSample
WHERE InvoiceTotal IS NOT NULL;
