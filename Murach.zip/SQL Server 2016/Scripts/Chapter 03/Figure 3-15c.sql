USE Examples;

SELECT *
FROM NullSample
WHERE InvoiceTotal <> 0;


