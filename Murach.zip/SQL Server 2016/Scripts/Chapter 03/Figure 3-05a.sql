USE AP;

SELECT VendorCity, VendorState, VendorCity + VendorState
FROM Vendors;
