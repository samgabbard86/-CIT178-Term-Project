USE AP;

SELECT DISTINCT VendorCity, VendorState
FROM Vendors;
