USE AP;

SELECT *
FROM Vendors
WHERE VendorState = 'CA'
ORDER BY VendorID;