USE New_AP;

CREATE TABLE SequenceTable(
    SequenceNo     INT,
    Description    VARCHAR(50));
