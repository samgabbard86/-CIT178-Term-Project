CREATE DATABASE Test_AP
    ON PRIMARY (FILENAME = 'C:\Murach\SQL Server 2012\Databases\Test_AP.mdf')
    FOR ATTACH;
