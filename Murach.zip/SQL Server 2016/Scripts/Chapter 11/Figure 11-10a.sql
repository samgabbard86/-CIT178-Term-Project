USE New_AP;

DROP INDEX Invoices.IX_Invoices;