USE New_AP;

INSERT Invoices3
VALUES (-100);
