USE New_AP;

ALTER TABLE Vendors
DROP COLUMN LastTranDate;
