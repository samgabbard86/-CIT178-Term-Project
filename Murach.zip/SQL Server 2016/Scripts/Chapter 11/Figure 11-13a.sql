USE New_AP;

DROP SEQUENCE TestSequence2;