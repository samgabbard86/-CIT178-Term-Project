USE New_AP;

INSERT Invoices9
VALUES (1, 99, 100);
