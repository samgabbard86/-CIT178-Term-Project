USE New_AP;

DROP TABLE Vendors1;