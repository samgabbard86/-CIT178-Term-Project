USE AP;

DELETE VendorCopy
WHERE VendorState = 'MN';
