USE AP;

INSERT InvoiceCopy
VALUES (32, 'AX-014-027', '2012-6-21', 434.58, 0, 0,
        2, '2012-07-08', NULL);
