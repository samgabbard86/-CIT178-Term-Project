USE AP;
GO

EXEC GetTop10Vendors;