USE AP;

CREATE ASSEMBLY ApExClrObjects
FROM 'C:\Murach\SQL Server 2016\Exercises\Chapter 20\ApExClrObjects.dll';