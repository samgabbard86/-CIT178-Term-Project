UPDATE VendorAddress
SET VendorAddress1 = '1990 Westwood Blvd',
    VendorAddress2 = 'Ste 260'
WHERE VendorID = 4;
