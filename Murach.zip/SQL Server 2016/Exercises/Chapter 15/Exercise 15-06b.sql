USE AP;

SELECT *
FROM dbo.fnDateRange('12/10/15','12/20/15');
