USE AP;

CREATE TABLE ShippingLabels
(VendorName varchar(50),
 VendorAddress1	varchar(50),
 VendorAddress2 varchar(50),
 VendorCity varchar(50),
 VendorState char(2),
 VendorZipCode varchar(20));
